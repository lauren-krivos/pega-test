import React, { Component, useState } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faCoffee } from '@fortawesome/free-solid-svg-icons'
import {
  FaSearch,
  FaPlusSquareO,
  FaHome,
  FaStarO,
  FaSquareO,
  FaFolder,
  FaPlus,
} from 'react-icons/fa';

import {
  BrowserRouter as Router, Route, Switch, Link
} from 'react-router-dom';
import './App.scss';
import EpicsComponent from './components/pages/epics-component';
import BugsComponent from './components/pages/bugs-component';

const App = () =>{
  const [showMenu, setShowMenu] = useState(false);
  const [isShown, setIsShown] = useState(false);

    return (
      <Router>
        <div className="App">
            <div className="ribbon-menu-wrapper"
                 onFocus={() => setIsShown(true)}
                 onMouseEnter={() => setIsShown(true)}
                 onMouseLeave={() => setIsShown(false)}
            >
              {!isShown && (
                <nav className="ribbon-menu-nav ribbon-menu-nav-closed" tabIndex="1">
                  <ul>
                    <li className="menu-text">
                      <Link to="/">Pega</Link>
                    </li>
                    <li>
                      <Link to="/search">
                        <FaSearch />
                      </Link>
                    </li>
                    <div className="line-break" />
                    <li>
                      <Link to="/home"><FaPlus /></Link>
                    </li>
                    <li>
                      <Link to="/home"><FaHome /></Link>
                    </li>
                    <li>
                      <Link to="/star"><FaFolder /></Link>
                    </li>
                    <li>
                      <Link to="/squares2"><FaFolder /></Link>
                    </li>
                    <li>
                      <Link to="/envelope"><FaFolder /></Link>
                    </li>
                    <li>
                      <Link to="/person"><FaFolder /></Link>
                    </li>
                    <li>
                      <Link to="/square"><FaFolder /></Link>
                    </li>
                    <li>
                      <Link to="/home"><FaHome /></Link>
                    </li>
                  </ul>
                </nav>
              )}
              {isShown && (
                <nav className="ribbon-menu-nav ribbon-menu-nav-open">
                  <ul>
                    <li className="menu-text">
                      <Link to="/">Pega</Link>
                    </li>
                    <li>
                      <Link to="/search">
                        <FaSearch />
                         <span className="menu-text"> Search</span>
                      </Link>
                    </li>
                    <div className="line-break" />
                    <button className="expand-button" onClick={() => setShowMenu(!showMenu)}>
                      <FaPlus />
                      <span className="menu-text"> Create</span>
                    </button>
                    {showMenu &&
                    <div className="hidden-stuff">
                      <li className="menu-text">
                        <Link to="/bugs">Bugs</Link>
                      </li>
                      <li className="menu-text">
                        <Link to="/epics">Epics</Link>
                      </li>
                    </div>
                    }
                    <li>
                      <Link to="/home">
                        <FaHome />
                        <span className="menu-text"> Home</span>
                      </Link>
                    </li>
                    <li>
                      <Link to="/star">
                        <FaFolder />
                        <span className="menu-text"> My Dashboard</span>
                      </Link>
                    </li>
                    <li>
                      <Link to="/squares2">
                        <FaFolder />
                        <span className="menu-text"> Spaces</span>
                      </Link>
                    </li>
                    <li>
                      <Link to="/envelope">
                        <FaFolder />
                        <span className="menu-text"> Documents</span>
                      </Link>
                    </li>
                    <li>
                      <Link to="/person">
                        <FaFolder />
                        <span className="menu-text"> Bugs</span>
                      </Link>
                    </li>
                    <li>
                      <Link to="/epics">
                        <FaFolder />
                        <span className="menu-text"> Epics</span>
                      </Link>
                    </li>
                    <li>
                      <Link to="/home">
                        <FaHome />
                        <span className="menu-text"> Goals</span>
                      </Link>
                    </li>
                  </ul>
                </nav>
              )}
            </div>
            <div className="app-content">
              <Switch>
                <Route path="/bugs">
                  <BugsComponent />
                </Route>
                <Route path="/epics">
                  <EpicsComponent />
                </Route>
              </Switch>
            </div>

          {/* A <Switch> looks through its children <Route>s and
            renders the first one that matches the current URL. */}
        </div>
      </Router>
    );
};

export default App;
