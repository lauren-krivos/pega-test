import React from 'react';

const BugsComponent = () => (
  <div>
    <span className="test-class">BUGS</span>
  </div>
);

export default BugsComponent;
