import React from 'react';

const EpicsComponent = () => (
  <div>
    <span className="test-class">EPICS</span>
  </div>
);

export default EpicsComponent;
