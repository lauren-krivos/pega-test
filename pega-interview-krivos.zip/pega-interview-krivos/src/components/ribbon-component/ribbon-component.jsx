import React from 'react';

const RibbonMenuComponent = () => (
  <div>component1 test
    <span className="test-class">BUGS</span>
  </div>
);

export default RibbonMenuComponent;
